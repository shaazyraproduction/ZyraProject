
import os, sqlite3, json, hashlib
from datetime import datetime, timezone
from pathlib import Path
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel

APP_VERSION = "1.0.0-production-candidate"
DB_PATH = os.getenv("ZYRA_DB", "zyra.db")
API_KEY = os.getenv("ZYRA_API_KEY")

app = FastAPI(title="ZYRA MASTER HUB Runtime", version=APP_VERSION)

class RunRequest(BaseModel):
    request: str
    capability: str

def now():
    return datetime.now(timezone.utc).isoformat()

def db():
    con = sqlite3.connect(DB_PATH)
    con.execute("""CREATE TABLE IF NOT EXISTS audit (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ts TEXT NOT NULL, event TEXT NOT NULL, payload TEXT NOT NULL,
        sha256 TEXT NOT NULL
    )""")
    return con

def audit(event, payload):
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":"))
    digest = hashlib.sha256(raw.encode()).hexdigest()
    con = db()
    con.execute("INSERT INTO audit(ts,event,payload,sha256) VALUES(?,?,?,?)",
                (now(), event, raw, digest))
    con.commit()
    con.close()

def auth(x_api_key):
    if API_KEY is None:
        raise HTTPException(503, "Production API key is not configured")
    if x_api_key != API_KEY:
        raise HTTPException(401, "Unauthorized")

@app.get("/health")
def health():
    con = db(); con.execute("SELECT 1"); con.close()
    return {"status": "PASS", "service": "zyra-runtime", "version": APP_VERSION}

@app.get("/ready")
def ready():
    configured = API_KEY is not None
    return {"status": "PASS" if configured else "NOT_READY",
            "api_key_configured": configured,
            "database": "sqlite"}

@app.post("/v1/run")
def run(body: RunRequest, x_api_key: str | None = Header(default=None)):
    auth(x_api_key)
    audit("REQUEST", body.model_dump())
    # Safe production boundary: only registered local capability is executable.
    if body.capability != "ai_system_development":
        audit("ROUTE_FAIL", {"capability": body.capability})
        raise HTTPException(404, "Capability is not registered for this deployment")
    result = {
        "status": "PASS",
        "system_id": "ZASDE-001",
        "output": {
            "message": "Production-candidate local adapter executed",
            "request": body.request
        }
    }
    audit("ACCEPT", result)
    return result

@app.get("/v1/audit")
def audit_list(x_api_key: str | None = Header(default=None)):
    auth(x_api_key)
    con = db()
    rows = con.execute("SELECT id,ts,event,payload,sha256 FROM audit ORDER BY id").fetchall()
    con.close()
    return [{"id":r[0],"ts":r[1],"event":r[2],"payload":json.loads(r[3]),"sha256":r[4]} for r in rows]
