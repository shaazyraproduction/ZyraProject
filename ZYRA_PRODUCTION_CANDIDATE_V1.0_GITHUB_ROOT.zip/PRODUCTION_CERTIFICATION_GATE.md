
# ZYRA Production Certification Gate

## Current evidence
- Local runtime core: implemented and tested.
- Production-candidate HTTP service: implemented and locally tested.
- Architecture baseline V1–V20 remains the source architecture.
- Certification is NOT claimed.

## Required gates
1. Deploy to an authorized production environment.
2. Connect real approved systems through verified adapters/connectors.
3. Establish identity, authorization, secrets, TLS and network controls.
4. Establish observability, alerting, audit retention and incident response.
5. Run integration, load, failure, backup/restore and security tests.
6. Capture immutable evidence and provenance.
7. Obtain authorized acceptance.
8. Execute V20 certification review and baseline lock.

## Stop rule
Do not label the system CERTIFIED until every gate above has evidence and authorized acceptance.
