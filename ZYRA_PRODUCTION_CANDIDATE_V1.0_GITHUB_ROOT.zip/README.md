
# ZYRA MASTER HUB — Production Candidate V1.0

This package moves the local runtime toward a deployable service:
FastAPI HTTP boundary, API-key authentication, SQLite audit store, health/readiness,
container packaging, and tests.

It is a **production candidate**, not a certified production deployment.

Run locally:
    pip install -r requirements.txt
    ZYRA_API_KEY=test-secret pytest -q

Run service:
    ZYRA_API_KEY=change-me uvicorn app.main:app --host 0.0.0.0 --port 8080

For real production, follow PRODUCTION_CERTIFICATION_GATE.md.
