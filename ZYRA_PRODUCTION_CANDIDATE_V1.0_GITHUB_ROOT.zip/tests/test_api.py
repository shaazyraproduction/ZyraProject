
import os, tempfile
os.environ["ZYRA_API_KEY"] = "test-secret"
fd, path = tempfile.mkstemp(suffix=".db"); os.close(fd)
os.environ["ZYRA_DB"] = path

from fastapi.testclient import TestClient
from app.main import app
client = TestClient(app)

def test_health():
    r = client.get("/health")
    assert r.status_code == 200
    assert r.json()["status"] == "PASS"

def test_ready():
    r = client.get("/ready")
    assert r.json()["status"] == "PASS"

def test_auth_required():
    r = client.post("/v1/run", json={"request":"x","capability":"ai_system_development"})
    assert r.status_code == 401

def test_run_and_audit():
    r = client.post("/v1/run", headers={"x-api-key":"test-secret"},
                    json={"request":"x","capability":"ai_system_development"})
    assert r.status_code == 200
    assert r.json()["status"] == "PASS"
    a = client.get("/v1/audit", headers={"x-api-key":"test-secret"})
    assert a.status_code == 200
    assert len(a.json()) >= 2

def test_unknown_capability():
    r = client.post("/v1/run", headers={"x-api-key":"test-secret"},
                    json={"request":"x","capability":"unknown"})
    assert r.status_code == 404
